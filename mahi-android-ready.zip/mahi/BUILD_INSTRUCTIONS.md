# Building the Mahi Android APK

I can't compile the actual `.apk` from where I'm running (no internet access
and no Android SDK/Gradle in this sandbox), so this project is prepped and
ready — you just need to run these steps on your own machine once. Total
time: ~10-15 minutes if Android Studio is already installed.

## Prerequisites

- **Node.js 18+** (you likely have this already, since it's a Vite project)
- **Android Studio** (installs the Android SDK + Gradle for you):
  https://developer.android.com/studio
- A **Gemini API key** — https://aistudio.google.com/apikey

## 1. Install dependencies

```bash
npm install
```

This pulls in `@capacitor/core`, `@capacitor/android`, and `@capacitor/cli`,
which are already added to `package.json`.

## 2. Set your API key

```bash
cp .env.example .env
```

Edit `.env` and put your key in `VITE_GEMINI_API_KEY`.

> ⚠️ You chose the client-side key approach for now (dev/personal use).
> That's fine for testing, but remember: anyone who unzips the APK can pull
> the key back out of the bundled JS. Don't publish this build publicly or
> share the APK widely without moving to a backend proxy first — see the
> note at the bottom of this file.

## 3. Generate the native Android project

```bash
npm run build
npx cap add android
```

This creates the `android/` folder — a full native Gradle project — using
Capacitor's official template (this step needs internet access, which is why
it has to happen on your machine, not in this sandbox).

## 4. Enable the microphone

The stock Android WebView silently blocks `getUserMedia()` (the mic API
Mahi uses) unless you explicitly wire it up. Two small edits, both already
prepared for you in `capacitor-android-overrides/`:

**a) Replace MainActivity**

Copy `capacitor-android-overrides/MainActivity.java` over the generated file
at:
```
android/app/src/main/java/com/mahi/assistant/MainActivity.java
```

**b) Add permissions to the manifest**

Open `android/app/src/main/AndroidManifest.xml` and add the two lines from
`capacitor-android-overrides/AndroidManifest-additions.xml` (just above the
`<application>` tag).

## 5. Add the app icon & splash screen

A placeholder icon/splash matching the app's purple-orb look is in
`assets/` (`icon.png`, `icon-foreground.png`, `splash.png`). Swap these for
your own artwork any time — same filenames, same folder.

```bash
npx @capacitor/assets generate --android
```

This writes all the mipmap/drawable resolutions Android needs into
`android/app/src/main/res/`.

## 6. Sync and build

```bash
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK lands at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Install it on a connected device/emulator:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

Or just open the project in Android Studio instead of using the CLI:
```bash
npx cap open android
```
then click **Run**.

## 7. (Optional) Release build

Debug builds work fine for personal use. For a signed release APK you'd
distribute:

```bash
keytool -genkey -v -keystore mahi-release.keystore -alias mahi -keyalg RSA -keysize 2048 -validity 10000
```

Then configure signing in `android/app/build.gradle` and run:
```bash
./gradlew assembleRelease
```
Android Studio's **Build > Generate Signed Bundle / APK** wizard does this
same thing with a GUI if you'd rather avoid editing Gradle files by hand.

## Moving the API key server-side later

When you're ready to share the app beyond your own device, the standard
pattern is: your backend issues short-lived Gemini Live ephemeral tokens,
and the app requests a token from your server instead of holding the real
key. Google's Live API docs cover ephemeral token issuance if/when you want
to do this.
