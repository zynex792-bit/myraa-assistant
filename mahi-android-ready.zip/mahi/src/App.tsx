import { useEffect, useRef, useState } from "react";
import { GoogleGenAI, Modality } from "@google/genai";

type Status = "disconnected" | "connecting" | "listening" | "speaking";
const MODEL = "gemini-3.1-flash-live-preview";

function base64ToBytes(base64: string) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function pcm16ToFloat32(bytes: Uint8Array) {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const output = new Float32Array(bytes.byteLength / 2);
  for (let i = 0; i < output.length; i++) {
    output[i] = view.getInt16(i * 2, true) / 32768;
  }
  return output;
}

function floatTo16BitPCM(input: Float32Array) {
  const output = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const sample = Math.max(-1, Math.min(1, input[i]));
    output[i] = sample < 0 ? sample * 32768 : sample * 32767;
  }
  return new Uint8Array(output.buffer);
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

class AudioStreamer {
  private context: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;

  async start(onAudio: (pcm: Uint8Array) => void) {
    this.context = new AudioContext({ sampleRate: 16000 });
    await this.context.resume();

    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    });

    this.source = this.context.createMediaStreamSource(this.stream);
    this.processor = this.context.createScriptProcessor(4096, 1, 1);

    this.processor.onaudioprocess = (event) => {
      onAudio(floatTo16BitPCM(event.inputBuffer.getChannelData(0)));
    };

    this.source.connect(this.processor);
    this.processor.connect(this.context.destination);
  }

  stop() {
    this.processor?.disconnect();
    this.source?.disconnect();
    this.stream?.getTracks().forEach((track) => track.stop());
    this.context?.close();
    this.processor = null;
    this.source = null;
    this.stream = null;
    this.context = null;
  }
}

class AudioPlayer {
  private context: AudioContext | null = null;
  private nextStartTime = 0;

  async init() {
    this.context = new AudioContext({ sampleRate: 24000 });
    await this.context.resume();
    this.nextStartTime = this.context.currentTime;
  }

  play(bytes: Uint8Array) {
    if (!this.context) return;
    const samples = pcm16ToFloat32(bytes);
    const buffer = this.context.createBuffer(1, samples.length, 24000);
    buffer.copyToChannel(samples, 0);

    const source = this.context.createBufferSource();
    source.buffer = buffer;
    source.connect(this.context.destination);

    const startTime = Math.max(this.nextStartTime, this.context.currentTime);
    source.start(startTime);
    this.nextStartTime = startTime + buffer.duration;
  }

  interrupt() {
    if (this.context) this.nextStartTime = this.context.currentTime;
  }

  destroy() {
    this.context?.close();
    this.context = null;
  }
}

export default function App() {
  const [status, setStatus] = useState<Status>("disconnected");
  const [error, setError] = useState("");
  const sessionRef = useRef<any>(null);
  const audioStreamer = useRef(new AudioStreamer());
  const audioPlayer = useRef(new AudioPlayer());
  const runningRef = useRef(false);

  async function startMahi() {
    if (runningRef.current) return;
    setError("");
    setStatus("connecting");

    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
      if (!apiKey) throw new Error("VITE_GEMINI_API_KEY missing");

      const ai = new GoogleGenAI({ apiKey });
      await audioPlayer.current.init();

      const session = await ai.live.connect({
        model: MODEL,
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: `You are Mahi, a young, confident, witty and playful female AI voice assistant.
Be friendly, smart, slightly teasing, expressive, warm and natural.
Never be explicit, sexual, abusive or inappropriate.
Speak naturally like a close friend. Keep responses conversational.
You are a voice-only assistant. If interrupted, stop responding and listen.`,
          tools: [{
            functionDeclarations: [{
              name: "openWebsite",
              description: "Open a website in the user's browser.",
              parameters: {
                type: "OBJECT",
                properties: { url: { type: "STRING", description: "Complete URL to open." } },
                required: ["url"],
              },
            }],
          }],
        },
        callbacks: {
          onopen() {
            runningRef.current = true;
            setStatus("listening");
          },
          onmessage(message: any) {
            const serverContent = message.serverContent;

            if (serverContent?.interrupted) {
              audioPlayer.current.interrupt();
              setStatus("listening");
            }

            const parts = serverContent?.modelTurn?.parts;
            if (parts) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  setStatus("speaking");
                  audioPlayer.current.play(base64ToBytes(part.inlineData.data));
                }
              }
            }

            if (message.toolCall) handleToolCall(message.toolCall);
            if (serverContent?.turnComplete) setStatus("listening");
          },
          onerror(event: any) {
            console.error(event);
            setError(event?.message || "Gemini connection error");
            stopMahi();
          },
          onclose() {
            runningRef.current = false;
            setStatus("disconnected");
          },
        },
      });

      sessionRef.current = session;

      await audioStreamer.current.start((pcm) => {
        if (!runningRef.current) return;
        session.sendRealtimeInput({
          audio: { data: bytesToBase64(pcm), mimeType: "audio/pcm;rate=16000" },
        });
      });
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Unable to start Mahi");
      stopMahi();
    }
  }

  function handleToolCall(toolCall: any) {
    const functionCalls = toolCall.functionCalls || [];
    const responses: any[] = [];

    for (const call of functionCalls) {
      if (call.name === "openWebsite") {
        const url = call.args?.url;
        if (typeof url === "string") {
          const safeUrl = /^https?:\/\//i.test(url) ? url : `https://${url}`;
          window.open(safeUrl, "_blank", "noopener,noreferrer");
          responses.push({
            id: call.id,
            name: call.name,
            response: { success: true, message: "Website opened successfully." },
          });
        }
      }
    }

    if (responses.length) sessionRef.current?.sendToolResponse({ functionResponses: responses });
  }

  function stopMahi() {
    runningRef.current = false;
    audioStreamer.current.stop();
    audioPlayer.current.interrupt();
    audioPlayer.current.destroy();

    try { sessionRef.current?.close(); } catch {}
    sessionRef.current = null;
    setStatus("disconnected");
  }

  function toggleMahi() {
    if (runningRef.current) stopMahi();
    else startMahi();
  }

  useEffect(() => () => stopMahi(), []);

  const statusText = {
    disconnected: "TAP TO TALK",
    connecting: "CONNECTING...",
    listening: "LISTENING...",
    speaking: "MAHI IS SPEAKING...",
  };

  return (
    <main className="app">
      <div className="backgroundGlow glowOne" />
      <div className="backgroundGlow glowTwo" />

      <header className="header">
        <div className="logo"><span className="logoDot" />MAHI</div>
        <div className="connection">
          <span className={status === "disconnected" ? "offline" : "online"} />
          {status === "disconnected" ? "OFFLINE" : "LIVE"}
        </div>
      </header>

      <section className="assistant">
        <div className={`orb orb-${status}`}>
          <div className="orbInner"><span>MAHI</span></div>
        </div>

        <div className="wave">
          {Array.from({ length: 21 }).map((_, index) => (
            <i key={index} className={status === "speaking" ? "bar active" : "bar"}
              style={{ animationDelay: `${index * 0.04}s` }} />
          ))}
        </div>

        <h1>Hey, I'm Mahi.</h1>
        <p className="status">{statusText[status]}</p>
        {error && <p className="error">{error}</p>}

        <button className={`mic ${status !== "disconnected" ? "micActive" : ""}`}
          onClick={toggleMahi} aria-label="Toggle Mahi">
          <span className="micIcon">{status === "disconnected" ? "🎙" : "■"}</span>
        </button>

        <p className="hint">
          {status === "disconnected" ? "Tap the button and start talking" : "I'm listening..."}
        </p>
      </section>

      <footer>GEMINI LIVE • VOICE AI</footer>
    </main>
  );
}
