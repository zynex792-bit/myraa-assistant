# Building the Mahi APK from your phone (no computer needed)

This uses GitHub's free cloud build servers (GitHub Actions) to compile the
APK for you. Everything below can be done from a mobile browser.

## 1. Create a GitHub account

Go to https://github.com/signup in your phone's browser and sign up (free).

## 2. Create a new repository

- Tap the **+** icon (top right) → **New repository**
- Name it e.g. `mahi-android`
- Choose **Private** (recommended, keeps your code out of public search)
- Tap **Create repository**

## 3. Upload this project

- On the empty repo page, tap **uploading an existing file**
  (or **Add file → Upload files**)
- Select the `mahi-android-ready.zip` file from your phone's Downloads
- GitHub will ask **"Would you like to expand the uploaded zip file?"** →
  tap **Yes** — this unpacks all the folders correctly
- Scroll down, tap **Commit changes**

## 4. Add your Gemini API key as a secret

Never put the real key in the code — GitHub Actions will inject it at build
time instead.

- In your repo, go to **Settings → Secrets and variables → Actions**
- Tap **New repository secret**
- Name: `VITE_GEMINI_API_KEY`
- Value: paste your actual key from https://aistudio.google.com/apikey
- Tap **Add secret**

## 5. Run the build

- Go to the **Actions** tab in your repo
- You should see a workflow called **Build Mahi APK**
  - If it hasn't started automatically, tap it → **Run workflow** → **Run workflow**
- Tap into the running job and wait (~5-8 minutes). You'll see live logs.

## 6. Download the APK

- Once it finishes with a green checkmark, scroll to the bottom of that run
  page to **Artifacts**
- Tap **mahi-debug-apk** to download it (comes as a `.zip` containing the
  `.apk` — your phone will likely auto-extract it, or use any file manager
  app to unzip)

## 7. Install it

- Open the downloaded `app-debug.apk` with your phone's file manager
- Android will ask permission to **install unknown apps** for that app
  (usually your browser or Files app) — allow it, just for this install
- Tap **Install**

That's it — Mahi will be on your home screen like any other app.

## If the build fails

Open the failed run in the **Actions** tab and check which step has the red
X — that log almost always says exactly what went wrong (most common: a
typo in the secret name, or missing `.env` key). Paste me the error and
I'll help you fix it.

## Re-building after changes

Any time you edit files in the repo (or just re-upload a new zip) and
commit, the workflow runs automatically and produces a fresh APK in
Actions → Artifacts.
