import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mahi.assistant',
  appName: 'Mahi',
  webDir: 'dist',
  // Voice assistant needs the WebView to allow mixed timing for audio start
  // and to not sleep the mic stream when the screen briefly dims.
  android: {
    allowMixedContent: false,
  },
};

export default config;
