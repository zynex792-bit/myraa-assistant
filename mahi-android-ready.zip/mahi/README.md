# Mahi AI Assistant

Voice-only React + TypeScript + Vite starter using Gemini Live API.

## Setup

1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your Gemini API key in `VITE_GEMINI_API_KEY`.
5. Run `npm run dev`.

## Important security note

The included `.env` approach is intended for local development only. Do not ship a real Gemini API key inside a public browser build or APK. For production, put authentication/token issuance behind a secure backend and use an appropriate Live API client authentication flow.

## Included

- Gemini Live audio session
- PCM microphone capture at 16 kHz
- PCM audio playback at 24 kHz
- Interrupt handling
- Listening/speaking/connecting UI
- `openWebsite` function calling
- Mobile-first futuristic UI

## Build

`npm run build`

The resulting production files are generated in `dist/`.
