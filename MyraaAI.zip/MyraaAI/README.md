# Myraa – AI Voice Assistant (Android)

A complete, buildable Android Studio project implementing a Hindi/English/Hinglish
voice assistant with a modular command router, on-device actions (apps, flashlight,
alarms, WhatsApp with confirmation), and a pluggable AI-chat fallback for
general questions.

## 1. Project structure

```
MyraaAI/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties                  <- AI backend config lives here
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/myraa/assistant/
        │   ├── MyraaApplication.kt
        │   ├── MainActivity.kt
        │   ├── voice/
        │   │   ├── SpeechRecognitionManager.kt
        │   │   └── TextToSpeechManager.kt
        │   ├── command/
        │   │   ├── IntentType.kt
        │   │   ├── CommandResult.kt
        │   │   └── CommandRouter.kt
        │   ├── actions/
        │   │   ├── AppLauncherActions.kt
        │   │   ├── FlashlightAction.kt
        │   │   ├── AlarmAction.kt
        │   │   └── WhatsAppAction.kt
        │   ├── ai/
        │   │   ├── AiConfig.kt
        │   │   ├── AiApiService.kt
        │   │   └── AiRepository.kt
        │   └── util/
        │       ├── TextNormalizer.kt
        │       └── PermissionManager.kt
        └── res/
            ├── layout/activity_main.xml
            ├── values/{strings,colors,themes}.xml
            ├── drawable/ (mic icon, card/pill/mic backgrounds, adaptive icon)
            ├── mipmap-anydpi-v26/ (launcher icons)
            └── anim/pulse.xml
```

## 1a. Building & testing this entirely in a browser (no Android Studio)

Android apps can't literally *run inside* a browser tab (they need Android's
OS/runtime), but you can build and test Myraa 100% from the web using free
tools — nothing to install on your own computer.

### Option A — GitHub Actions (easiest: builds the APK for you)
1. Create a free GitHub account if you don't have one, and create a new
   **empty** repository (e.g. `myraa-assistant`) — do this from github.com in
   your browser.
2. Upload this whole `MyraaAI` folder's contents to that repo. Easiest way in
   the browser: on the repo page, click **Add file → Upload files**, then
   drag in everything from the extracted `MyraaAI` folder (including the
   hidden `.github` folder — if the web uploader hides it, use GitHub's
   **Codespaces** from Option B instead to `git add -A` everything).
3. Go to the repo's **Actions** tab → you'll see a workflow called
   **"Build Myraa Debug APK"** (already included at
   `.github/workflows/build.yml`) → click **Run workflow**.
4. Wait ~2-3 minutes. When it finishes, open the completed run and download
   the **`myraa-debug-apk`** artifact — that's your installable `.apk`,
   built entirely on GitHub's servers.
5. To actually *use* the app: either sideload that APK onto an Android phone,
   or upload it to **appetize.io** (free tier) which runs a real Android
   device in your browser tab — drag the APK onto appetize.io's upload page
   and it launches Myraa in an on-screen phone you can tap/speak to test
   with your computer's mic.

### Option B — Gitpod or GitHub Codespaces (full online IDE + terminal)
1. Push the project to a GitHub repo (as in Option A, step 1-2).
2. Open it with either:
   - **Gitpod**: visit `https://gitpod.io/#https://github.com/<you>/myraa-assistant`
     — a `.gitpod.yml` is already included, so it auto-installs the Android
     SDK for you.
   - **GitHub Codespaces**: on the repo page, click **Code → Codespaces →
     Create codespace on main**.
3. In the browser-based terminal that opens, run:
   ```bash
   ./gradlew assembleDebug
   ```
4. Download the resulting file at `app/build/outputs/apk/debug/app-debug.apk`
   from the file explorer sidebar (right-click → Download), then test it via
   appetize.io as in Option A step 5, or sideload it onto a real phone.

Both options need **zero local installation** — everything happens on
GitHub's/Gitpod's servers, accessed entirely through your browser.

## 2. How the pipeline works

```
User speech
  → SpeechRecognitionManager (Android SpeechRecognizer)
  → TextNormalizer (lower-cases + maps common Hindi/Hinglish phrases → English keywords)
  → CommandRouter (regex-based intent matching)
      ├─ matched → actions/* (real Android Intent/API call) → CommandResult
      └─ unmatched → ai/AiRepository → your backend → CommandResult
  → MainActivity renders CommandResult + TextToSpeechManager speaks it
```

Device actions and the AI layer never call each other directly — `CommandRouter`
is the only class that knows both exist, which is what keeps the architecture
modular and lets you add new commands by touching only `CommandRouter` +
`actions/`.

## 3. Setting up the project in Android Studio

1. **Install Android Studio** (Koala/2024.1 or newer recommended) with Android
   SDK Platform 34 and Build-Tools 34 installed via the SDK Manager.
2. **Copy this whole `MyraaAI/` folder** to your machine, e.g. `~/AndroidStudioProjects/MyraaAI`.
3. Open Android Studio → **Open** → select the `MyraaAI` folder (the one containing
   `settings.gradle.kts`).
4. Android Studio will detect there's no `gradle-wrapper.jar`. Either:
   - Let Android Studio regenerate it automatically on first sync (it usually
     offers to), **or**
   - Run `gradle wrapper --gradle-version 8.7` from a terminal inside the
     project folder if you have a system Gradle install, **or**
   - In Android Studio: **File → Sync Project with Gradle Files** — the IDE's
     bundled Gradle can bootstrap the wrapper for you.
5. Every source/resource file listed above already exists in the folder —
   nothing needs to be manually placed if you opened the correct root folder.

## 4. Syncing Gradle

- After opening the project, click **"Sync Now"** in the top banner, or
  **File → Sync Project with Gradle Files**.
- First sync will download AndroidX, Material Components, ConstraintLayout,
  OkHttp, and Kotlin Coroutines dependencies declared in `app/build.gradle.kts`.
- If sync fails on the Gradle wrapper JAR, see step 4 above.

## 5. Configuring the AI backend (no keys in the app!)

Myraa's Kotlin code **never** contains an LLM provider API key. Instead:

1. Open `gradle.properties` at the project root.
2. Set:
   ```properties
   MYRAA_AI_BASE_URL=https://your-backend.example.com/chat
   MYRAA_AI_MODEL=claude-sonnet-4-6
   MYRAA_AI_AUTH_TOKEN=<a token identifying THIS APP to YOUR backend>
   ```
3. These values are compiled into `BuildConfig.AI_BASE_URL` / `AI_MODEL` /
   `AI_AUTH_TOKEN` automatically (see `app/build.gradle.kts`) and read by
   `ai/AiConfig.kt`.

### What your backend needs to do
Your own server (Cloud Run, Lambda, a small Node/Python service, etc.) should:
- Accept a POST request with `{ "model": "...", "message": "..." }` and the
  `Authorization: Bearer <MYRAA_AI_AUTH_TOKEN>` header sent by `AiApiService.kt`.
- Verify that bearer token belongs to a real installed-app user (rotate/issue
  per-install or per-user tokens — don't ship one shared secret in a public APK).
- Internally call your LLM provider using a **server-side-only** provider API
  key that never leaves your infrastructure.
- Respond with `{ "reply": "short natural-language answer" }`.

This keeps the real provider key off the device entirely — even a decompiled
APK only ever reveals your app-level bearer token, which you can revoke/rotate
independently of the LLM provider key.

If `MYRAA_AI_BASE_URL` / `MYRAA_AI_AUTH_TOKEN` are left as placeholders,
`AiConfig.isConfigured` is `false` and Myraa will honestly tell the user the
AI backend isn't configured yet instead of pretending to answer.

## 6. Granting permissions

Myraa requests permissions **contextually**, not all at app launch:

| Permission | Requested when | Why |
|---|---|---|
| `RECORD_AUDIO` | First tap of the mic button | Needed for speech recognition |
| `CAMERA` | First flashlight command | `CameraManager.setTorchMode` requires it |
| `READ_CONTACTS` | First "message X on WhatsApp" command | To find the contact's number — Myraa never guesses one |

If you deny a permission, Myraa tells you plainly that the feature can't work
until it's granted (see `permission_denied_generic` string) — it never
pretends the action happened.

To grant manually: **Settings → Apps → Myraa → Permissions**.

## 7. Building the APK

- **Debug APK** (for testing on your own device/emulator):
  - Android Studio: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
  - Or from terminal: `./gradlew assembleDebug` — output at
    `app/build/outputs/apk/debug/app-debug.apk`.
- **Release APK** (signed, for distribution):
  - **Build → Generate Signed Bundle / APK → APK**, create/select a keystore,
    choose the `release` build type. Release builds have `isMinifyEnabled = true`
    with the provided `proguard-rules.pro`.

## 8. Testing each voice command

Run the app on a real device (emulators often lack a working microphone/TTS
voices — a physical phone is strongly recommended). Tap the mic, wait for
"Listening…", then say:

| Say | Expected behavior |
|---|---|
| "Open YouTube" | YouTube app opens (or its website if not installed) |
| "Search YouTube for Minecraft videos" | YouTube opens with those search results |
| "Play latest songs on YouTube" | YouTube opens with search results for "latest songs" |
| "Open Instagram" | Instagram opens if installed, else Myraa says it can't |
| "Open WhatsApp" | WhatsApp opens |
| "Message Rahul saying I'm on my way" | Myraa looks up "Rahul" in contacts, shows a confirm dialog with the exact name/number found, and only opens WhatsApp's chat (pre-filled, not auto-sent) after you tap Confirm |
| "Open Chrome" / "Open Camera" / "Open Gallery" / "Open Calculator" / "Open Google Maps" / "Open Settings" | Each opens the corresponding app/screen |
| "Turn flashlight on" / "Turn flashlight off" | Torch toggles (after granting Camera permission on first use) |
| "Set an alarm for 7 AM" | Hands off to the system Clock app pre-filled at 7:00 AM |
| "Set an alarm for 6:30 tomorrow morning" | Clock app pre-filled at 6:30 AM |
| "Set an alarm for 6" (no AM/PM) | Myraa asks "Did you mean 6 AM or 6 PM?" instead of guessing |
| "What is photosynthesis?" | Falls through to the AI-chat backend (requires it to be configured — see §5) |
| Hindi/Hinglish: "YouTube khol do", "flashlight chalu karo", "alarm laga do 7 baje" | `TextNormalizer` maps these to the same intents as their English equivalents |

If speech recognition fails (no network for server-based recognizers, no
match, etc.), Myraa shows the specific error and says a short spoken apology
instead of silently retrying the mic — this avoids the "annoying repeated
mic popup" behavior explicitly ruled out in the spec.

## 9. Known Android platform restrictions (implemented honestly, not bypassed)

- **Auto-sending WhatsApp messages** isn't possible without WhatsApp exposing
  a public send API — Myraa opens a pre-filled chat and requires your final
  tap in WhatsApp itself. This is intentional, not a limitation to "fix."
- **Answering/rejecting incoming calls programmatically** requires your app
  to be granted the Android **default Phone/Dialer role**
  (`RoleManager.ROLE_DIALER`) or use a `CallScreeningService`/`InCallService`,
  both of which involve significant additional Play Store review and user
  setup. This MVP implements the legitimate subset (opening the dialer,
  preparing a call via `ACTION_DIAL`, opening Contacts) and does not attempt
  call-control without that role.
- **A universal "open Calculator" intent** doesn't exist in the Android
  framework — the app tries known calculator package names across major
  OEMs (Google, AOSP, Samsung, MIUI, OnePlus) rather than relying on any
  hidden/undocumented mechanism.
- **Exact alarms** use `AlarmClock.ACTION_SET_ALARM`, which hands off to
  whatever Clock app is installed — this is the supported, non-restricted way
  to create user-visible alarms without needing `SCHEDULE_EXACT_ALARM`.

## 10. Extending Myraa (future features listed in the spec)

To add e.g. Weather, Web search, Music control, Wi-Fi/Bluetooth toggles,
Volume control, Notifications, Calendar, Reminders, Battery/Device info, or
custom voice commands:

1. Add a new `IntentType` value in `command/IntentType.kt`.
2. Add the matching regex/keyword branch in `CommandRouter.tryDeviceCommand()`.
3. Implement the actual Android API/intent call in a new or existing file
   under `actions/`.
4. Return a `CommandResult` — nothing else in the app needs to change.

Wake-word support (e.g. "Hey Myraa") would require either a foreground
service with a continuously-listening on-device wake-word engine (like
Porcupine or a custom TFLite model), since Android's built-in
`SpeechRecognizer` is not designed for always-on background listening — this
is a larger addition intentionally left out of this stable first version.
