import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Load values from gradle.properties (root) so secrets/config stay out of source code.
val localProps = Properties().apply {
    val f = rootProject.file("gradle.properties")
    if (f.exists()) load(FileInputStream(f))
}

android {
    namespace = "com.myraa.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myraa.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Exposed to Kotlin code as BuildConfig.AI_BASE_URL etc.
        buildConfigField(
            "String",
            "AI_BASE_URL",
            "\"${localProps.getProperty("MYRAA_AI_BASE_URL", "https://your-backend.example.com/")}\""
        )
        buildConfigField(
            "String",
            "AI_MODEL",
            "\"${localProps.getProperty("MYRAA_AI_MODEL", "claude-sonnet-4-6")}\""
        )
        buildConfigField(
            "String",
            "AI_AUTH_TOKEN",
            "\"${localProps.getProperty("MYRAA_AI_AUTH_TOKEN", "")}\""
        )
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")

    // Networking for the AI backend call
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.json:json:20240303")

    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
}
