package com.myraa.assistant.command

/**
 * Every device-action intent Myraa currently understands. Adding a new
 * command = add an enum value here + a matching rule in CommandRouter +
 * (if it's a device action) a handler in the actions/ package. Nothing else
 * needs to change, which is the "modular, easy to extend" architecture
 * called for in the spec.
 */
enum class IntentType {
    OPEN_YOUTUBE,
    SEARCH_YOUTUBE,
    OPEN_INSTAGRAM,
    OPEN_WHATSAPP,
    MESSAGE_WHATSAPP_CONTACT,
    OPEN_CHROME,
    OPEN_CAMERA,
    OPEN_GALLERY,
    OPEN_CALCULATOR,
    OPEN_MAPS,
    OPEN_SETTINGS,
    OPEN_GENERIC_APP,
    OPEN_DIALER,
    OPEN_CONTACTS,
    FLASHLIGHT_ON,
    FLASHLIGHT_OFF,
    SET_ALARM,
    AI_CHAT,
    UNKNOWN
}
