package com.myraa.assistant.actions

import android.content.Context
import android.hardware.camera2.CameraManager
import android.util.Log

/**
 * Torch control via the modern CameraManager torch API (no deprecated
 * Camera1 APIs, no hidden broadcasts). Requires CAMERA permission and a
 * device that reports FLASH_INFO_AVAILABLE = true.
 */
object FlashlightAction {

    private const val TAG = "FlashlightAction"

    private fun getCameraManager(context: Context): CameraManager =
        context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private fun findFlashCameraId(cameraManager: CameraManager): String? {
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                val characteristics = cameraManager.getCameraCharacteristics(id)
                characteristics.get(
                    android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE
                ) == true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to enumerate cameras", e)
            null
        }
    }

    /** Returns true only if the torch was actually toggled successfully. */
    fun setTorch(context: Context, turnOn: Boolean): Boolean {
        val cameraManager = getCameraManager(context)
        val cameraId = findFlashCameraId(cameraManager) ?: return false
        return try {
            cameraManager.setTorchMode(cameraId, turnOn)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set torch mode", e)
            false
        }
    }

    fun deviceHasFlash(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(
            android.content.pm.PackageManager.FEATURE_CAMERA_FLASH
        )
    }
}
