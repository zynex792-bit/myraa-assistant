package com.myraa.assistant.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/**
 * Single source of truth for "do we currently have permission X". Keeping
 * this separate from Activity code means CommandRouter/actions can check
 * permissions without needing an Activity reference for anything beyond the
 * actual system request dialog (which still has to happen in MainActivity).
 */
object PermissionManager {

    fun hasRecordAudio(context: Context): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

    fun hasCamera(context: Context): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

    fun hasContacts(context: Context): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

    val requiredAtLaunch = arrayOf(
        Manifest.permission.RECORD_AUDIO
    )

    // Requested lazily, only right before the feature that needs them runs.
    const val REQUEST_CODE_RECORD_AUDIO = 1001
    const val REQUEST_CODE_CAMERA = 1002
    const val REQUEST_CODE_CONTACTS = 1003
}
