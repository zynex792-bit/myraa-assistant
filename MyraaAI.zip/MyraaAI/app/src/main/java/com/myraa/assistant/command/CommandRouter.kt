package com.myraa.assistant.command

import android.content.Context
import com.myraa.assistant.R
import com.myraa.assistant.actions.AlarmAction
import com.myraa.assistant.actions.AlarmTimeParseResult
import com.myraa.assistant.actions.AppLauncherActions
import com.myraa.assistant.actions.ContactMatch
import com.myraa.assistant.actions.FlashlightAction
import com.myraa.assistant.actions.WhatsAppAction
import com.myraa.assistant.ai.AiRepository
import com.myraa.assistant.util.PermissionManager
import com.myraa.assistant.util.TextNormalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch

/**
 * The command router described in the spec:
 *
 *   User speech -> Speech Recognition -> Text normalization
 *   -> Intent/command detection -> Required Android action -> Result
 *   -> Text-to-speech response
 *
 * This class owns steps 3-5. Text normalization happens first via
 * [TextNormalizer]. Device actions live in the actions/ package; the AI-chat
 * fallback lives in the ai/ package. This class only routes between them —
 * it never itself contains device API calls or network calls, which is what
 * keeps "AI layer separated from device-action logic" true in practice.
 */
class CommandRouter(
    private val context: Context,
    private val aiRepository: AiRepository = AiRepository()
) {
    // Router-scoped coroutine scope for the AI-chat fallback call. Cancelled
    // when the owning MainActivity calls cancelPendingWork() in onDestroy().
    private val routerScope = CoroutineScope(Dispatchers.Main)

    fun cancelPendingWork() {
        routerScope.coroutineContext.cancelChildren()
    }

    /**
     * Runs the whole pipeline for one utterance. [onResult] is called
     * exactly once, synchronously for device actions, or asynchronously
     * (from a coroutine) for the AI-chat fallback.
     */
    fun route(rawText: String, onResult: (CommandResult) -> Unit) {
        val text = TextNormalizer.normalize(rawText)

        val handled = tryDeviceCommand(text, rawText)
        if (handled != null) {
            onResult(handled)
            return
        }

        // Nothing matched a device command -> treat as a conversational
        // question for the AI layer. Emit an immediate "thinking" state so
        // the UI updates right away, then resolve the real answer async.
        onResult(
            CommandResult(
                intentType = IntentType.AI_CHAT,
                success = true,
                spokenResponse = "",
                displayText = context.getString(R.string.status_thinking)
            )
        )
        routeToAi(rawText, onResult)
    }

    private fun routeToAi(rawText: String, onResult: (CommandResult) -> Unit) {
        routerScope.launch {
            val result = aiRepository.ask(rawText)
            result.fold(
                onSuccess = { reply ->
                    onResult(
                        CommandResult(
                            intentType = IntentType.AI_CHAT,
                            success = true,
                            spokenResponse = reply,
                            displayText = reply
                        )
                    )
                },
                onFailure = { error ->
                    onResult(
                        CommandResult(
                            intentType = IntentType.AI_CHAT,
                            success = false,
                            spokenResponse = error.message
                                ?: "Sorry, I couldn't reach the AI service.",
                            displayText = error.message
                                ?: "Sorry, I couldn't reach the AI service."
                        )
                    )
                }
            )
        }
    }

    /**
     * Returns a CommandResult if [text] matched a known device command,
     * or null if nothing matched (meaning: fall through to AI chat).
     */
    private fun tryDeviceCommand(text: String, rawText: String): CommandResult? {
        return when {
            // --- YouTube ---
            Regex("play (.+) on youtube").find(text) != null -> {
                val query = Regex("play (.+) on youtube").find(text)!!.groupValues[1]
                runAction(IntentType.SEARCH_YOUTUBE, "Opening YouTube results for $query") {
                    AppLauncherActions.playOnYouTube(context, query)
                }
            }
            Regex("search (?:on )?youtube for (.+)").find(text) != null -> {
                val query = Regex("search (?:on )?youtube for (.+)").find(text)!!.groupValues[1]
                runAction(IntentType.SEARCH_YOUTUBE, "Searching YouTube for $query") {
                    AppLauncherActions.searchYouTube(context, query)
                }
            }
            text.contains("open youtube") -> {
                runAction(IntentType.OPEN_YOUTUBE, "Opening YouTube") {
                    AppLauncherActions.openYouTube(context)
                }
            }

            // --- WhatsApp ---
            Regex("message (\\w[\\w\\s]*?) saying (.+)").find(text) != null -> {
                val m = Regex("message (\\w[\\w\\s]*?) saying (.+)").find(text)!!
                buildWhatsAppConfirmation(m.groupValues[1].trim(), m.groupValues[2].trim())
            }
            text.contains("open whatsapp") -> {
                runAction(IntentType.OPEN_WHATSAPP, "Opening WhatsApp") {
                    AppLauncherActions.openWhatsApp(context)
                }
            }

            // --- Simple app opens ---
            text.contains("open instagram") -> runAction(
                IntentType.OPEN_INSTAGRAM, "Opening Instagram"
            ) { AppLauncherActions.openInstagram(context) }

            text.contains("open chrome") -> runAction(
                IntentType.OPEN_CHROME, "Opening Chrome"
            ) { AppLauncherActions.openChrome(context) }

            text.contains("open camera") -> runAction(
                IntentType.OPEN_CAMERA, "Opening camera"
            ) { AppLauncherActions.openCamera(context) }

            text.contains("open gallery") -> runAction(
                IntentType.OPEN_GALLERY, "Opening gallery"
            ) { AppLauncherActions.openGallery(context) }

            text.contains("open calculator") -> runAction(
                IntentType.OPEN_CALCULATOR, "Opening calculator"
            ) { AppLauncherActions.openCalculator(context) }

            text.contains("open maps") || text.contains("open google maps") -> runAction(
                IntentType.OPEN_MAPS, "Opening Maps"
            ) { AppLauncherActions.openMaps(context) }

            text.contains("open settings") -> runAction(
                IntentType.OPEN_SETTINGS, "Opening Settings"
            ) { AppLauncherActions.openSettings(context) }

            text.contains("open contacts") -> runAction(
                IntentType.OPEN_CONTACTS, "Opening Contacts"
            ) { AppLauncherActions.openContacts(context) }

            text.contains("open dialer") || text.contains("open phone") -> runAction(
                IntentType.OPEN_DIALER, "Opening phone dialer"
            ) { AppLauncherActions.openDialer(context) }

            Regex("open (\\w[\\w\\s]*)").find(text) != null -> {
                val appName = Regex("open (\\w[\\w\\s]*)").find(text)!!.groupValues[1].trim()
                runAction(IntentType.OPEN_GENERIC_APP, "Opening $appName") {
                    AppLauncherActions.openInstalledAppByName(context, appName)
                }
            }

            // --- Flashlight ---
            text.contains("flashlight") || text.contains("torch") -> {
                val turnOn = text.contains("on") && !text.contains("turn off")
                handleFlashlight(turnOn)
            }

            // --- Alarm ---
            text.contains("set") && text.contains("alarm") -> handleAlarm(text)

            else -> null
        }
    }

    private fun runAction(
        intentType: IntentType,
        successMessage: String,
        action: () -> Boolean
    ): CommandResult {
        val success = action()
        return if (success) {
            CommandResult(intentType, true, successMessage)
        } else {
            CommandResult(
                intentType,
                false,
                "I couldn't do that — the app or feature may not be available on this device."
            )
        }
    }

    private fun handleFlashlight(turnOn: Boolean): CommandResult {
        if (!PermissionManager.hasCamera(context)) {
            return CommandResult(
                if (turnOn) IntentType.FLASHLIGHT_ON else IntentType.FLASHLIGHT_OFF,
                false,
                "I need camera permission to control the flashlight. Please grant it in Settings."
            )
        }
        if (!FlashlightAction.deviceHasFlash(context)) {
            return CommandResult(
                if (turnOn) IntentType.FLASHLIGHT_ON else IntentType.FLASHLIGHT_OFF,
                false,
                "This device doesn't have a flashlight."
            )
        }
        val success = FlashlightAction.setTorch(context, turnOn)
        return CommandResult(
            if (turnOn) IntentType.FLASHLIGHT_ON else IntentType.FLASHLIGHT_OFF,
            success,
            if (success) "Flashlight turned ${if (turnOn) "on" else "off"}."
            else "I couldn't control the flashlight on this device."
        )
    }

    private fun handleAlarm(text: String): CommandResult {
        return when (val parsed = AlarmAction.parseTime(text)) {
            is AlarmTimeParseResult.Parsed -> {
                val success = AlarmAction.setAlarm(context, parsed.hour, parsed.minute)
                val timeStr = AlarmAction.formatTime12h(parsed.hour, parsed.minute)
                CommandResult(
                    IntentType.SET_ALARM,
                    success,
                    if (success) "Opening Clock to set an alarm for $timeStr."
                    else "I couldn't find a Clock app to set the alarm."
                )
            }
            is AlarmTimeParseResult.Ambiguous -> CommandResult(
                IntentType.SET_ALARM,
                false,
                parsed.clarifyingQuestion,
                needsConfirmation = false
            )
            AlarmTimeParseResult.NotFound -> CommandResult(
                IntentType.SET_ALARM,
                false,
                "What time would you like the alarm set for?"
            )
        }
    }

    /**
     * Builds a confirmation step for WhatsApp messaging. Nothing is sent
     * here — CommandRouter only looks up the contact and prepares what
     * *would* be sent, then hands a confirm callback back to the UI layer.
     * MainActivity is responsible for actually showing the confirmation
     * dialog and invoking onConfirm only after the user taps Confirm.
     */
    private fun buildWhatsAppConfirmation(contactName: String, message: String): CommandResult {
        if (!PermissionManager.hasContacts(context)) {
            return CommandResult(
                IntentType.MESSAGE_WHATSAPP_CONTACT,
                false,
                "I need contacts permission to find $contactName. Please grant it in Settings."
            )
        }

        val matches: List<ContactMatch> = WhatsAppAction.findContacts(context, contactName)
        if (matches.isEmpty()) {
            return CommandResult(
                IntentType.MESSAGE_WHATSAPP_CONTACT,
                false,
                "I couldn't find a contact named $contactName. I won't guess a number."
            )
        }
        // If there are multiple matches, use the first but say so clearly —
        // never silently guess among ambiguous contacts without disclosing it.
        val target = matches.first()
        val ambiguityNote = if (matches.size > 1) {
            " (found ${matches.size} matching contacts, using ${target.name})"
        } else ""

        return CommandResult(
            intentType = IntentType.MESSAGE_WHATSAPP_CONTACT,
            success = true,
            spokenResponse = "Send \"$message\" to ${target.name}$ambiguityNote on WhatsApp?",
            needsConfirmation = true,
            confirmationPayload = ConfirmationPayload(
                title = "Confirm WhatsApp message",
                message = context.getString(
                    R.string.confirm_send_whatsapp, message, target.name
                ),
                onConfirm = {
                    val sent = WhatsAppAction.openChatWithPrefilledMessage(
                        context, target.phoneNumber, message
                    )
                    CommandResult(
                        IntentType.MESSAGE_WHATSAPP_CONTACT,
                        sent,
                        if (sent) "Opened WhatsApp with your message to ${target.name} ready to send."
                        else "I couldn't open WhatsApp. Is it installed?"
                    )
                }
            )
        )
    }
}
