package com.myraa.assistant.command

/**
 * Outcome of executing a parsed command. [spokenResponse] is what
 * TextToSpeechManager says; [displayText] is what appears in the UI (usually
 * the same, but kept separate in case they ever need to diverge).
 *
 * [needsConfirmation] + [confirmationPayload] support flows like WhatsApp
 * messaging, where Myraa must NOT claim an action succeeded until the user
 * has explicitly confirmed and the send actually happened.
 */
data class CommandResult(
    val intentType: IntentType,
    val success: Boolean,
    val spokenResponse: String,
    val displayText: String = spokenResponse,
    val needsConfirmation: Boolean = false,
    val confirmationPayload: ConfirmationPayload? = null
)

/**
 * Everything needed to show a confirmation dialog and, if the user confirms,
 * actually perform the action. Kept generic so any future confirm-before-act
 * command (not just WhatsApp) can reuse it.
 */
data class ConfirmationPayload(
    val title: String,
    val message: String,
    val onConfirm: () -> CommandResult
)
