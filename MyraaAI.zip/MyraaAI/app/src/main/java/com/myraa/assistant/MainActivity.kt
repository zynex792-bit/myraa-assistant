package com.myraa.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.myraa.assistant.command.CommandResult
import com.myraa.assistant.command.CommandRouter
import com.myraa.assistant.command.ConfirmationPayload
import com.myraa.assistant.databinding.ActivityMainBinding
import com.myraa.assistant.util.PermissionManager
import com.myraa.assistant.voice.SpeechRecognitionManager
import com.myraa.assistant.voice.TextToSpeechManager

class MainActivity : AppCompatActivity(), SpeechRecognitionManager.Callback {

    private lateinit var binding: ActivityMainBinding
    private lateinit var speechManager: SpeechRecognitionManager
    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var commandRouter: CommandRouter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        speechManager = SpeechRecognitionManager(this, this)
        ttsManager = TextToSpeechManager(this) { isSpeaking ->
            runOnUiThread {
                if (isSpeaking) setStatus(getString(R.string.status_completed))
            }
        }
        commandRouter = CommandRouter(this)

        binding.btnMic.setOnClickListener { onMicTapped() }

        if (savedInstanceState == null) {
            setStatus(getString(R.string.status_ready))
            ttsManager.speak(getString(R.string.tts_greeting))
        }

        requestStartupPermissionsIfNeeded()
    }

    // ------------------------------------------------------------------
    // Mic button + listening UI state
    // ------------------------------------------------------------------

    private fun onMicTapped() {
        if (speechManager.isCurrentlyListening()) {
            // Prevent duplicate/annoying repeated triggers while already listening.
            return
        }
        if (!PermissionManager.hasRecordAudio(this)) {
            requestRecordAudioPermission()
            return
        }
        binding.tvRecognizedCommand.text = getString(R.string.hint_recognized_command)
        speechManager.startListening()
    }

    override fun onReadyForSpeech() {
        runOnUiThread {
            setStatus(getString(R.string.status_listening))
            setMicListeningVisual(true)
        }
    }

    override fun onPartialResult(text: String) {
        runOnUiThread {
            binding.tvRecognizedCommand.text = text
        }
    }

    override fun onFinalResult(text: String) {
        runOnUiThread {
            setMicListeningVisual(false)
            binding.tvRecognizedCommand.text = text
            setStatus(getString(R.string.status_thinking))
            commandRouter.route(text) { result -> handleCommandResult(result) }
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            setMicListeningVisual(false)
            setStatus(getString(R.string.status_error))
            binding.tvResponse.text = message
            ttsManager.speak(getString(R.string.tts_mic_error))
        }
    }

    private fun setMicListeningVisual(listening: Boolean) {
        binding.btnMic.isActivated = listening
        binding.pulseRing.visibility = if (listening) android.view.View.VISIBLE else android.view.View.INVISIBLE
        if (listening) {
            binding.pulseRing.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse))
        } else {
            binding.pulseRing.clearAnimation()
        }
    }

    // ------------------------------------------------------------------
    // Command result handling
    // ------------------------------------------------------------------

    private fun handleCommandResult(result: CommandResult) {
        binding.tvResponse.text = result.displayText

        if (result.needsConfirmation && result.confirmationPayload != null) {
            showConfirmationDialog(result.confirmationPayload)
            setStatus(getString(R.string.status_ready))
            if (result.spokenResponse.isNotBlank()) ttsManager.speak(result.spokenResponse)
            return
        }

        setStatus(
            if (result.success) getString(R.string.status_completed)
            else getString(R.string.status_error)
        )
        if (result.spokenResponse.isNotBlank()) {
            ttsManager.speak(result.spokenResponse)
        }
    }

    private fun showConfirmationDialog(payload: ConfirmationPayload) {
        AlertDialog.Builder(this)
            .setTitle(payload.title)
            .setMessage(payload.message)
            .setPositiveButton(R.string.btn_confirm) { dialog, _ ->
                dialog.dismiss()
                val confirmedResult = payload.onConfirm()
                handleCommandResult(confirmedResult)
            }
            .setNegativeButton(R.string.btn_cancel) { dialog, _ ->
                dialog.dismiss()
                binding.tvResponse.text = "Okay, I won't send that."
                setStatus(getString(R.string.status_ready))
            }
            .setCancelable(true)
            .show()
    }

    private fun setStatus(text: String) {
        binding.tvStatus.text = text
    }

    // ------------------------------------------------------------------
    // Permissions
    // ------------------------------------------------------------------

    private fun requestStartupPermissionsIfNeeded() {
        if (!PermissionManager.hasRecordAudio(this)) {
            // Don't request immediately on launch with no context — wait
            // until the user actually taps the mic, which is clearer about
            // *why* the permission is needed (better UX, same requirement
            // fulfilled: "explain why a permission is needed").
        }
    }

    private fun requestRecordAudioPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
            AlertDialog.Builder(this)
                .setTitle("Microphone access needed")
                .setMessage(getString(R.string.mic_permission_rationale))
                .setPositiveButton("Continue") { _, _ ->
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(Manifest.permission.RECORD_AUDIO),
                        PermissionManager.REQUEST_CODE_RECORD_AUDIO
                    )
                }
                .setNegativeButton("Cancel", null)
                .show()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                PermissionManager.REQUEST_CODE_RECORD_AUDIO
            )
        }
    }

    private fun requestCameraPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.CAMERA),
            PermissionManager.REQUEST_CODE_CAMERA
        )
    }

    private fun requestContactsPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.READ_CONTACTS),
            PermissionManager.REQUEST_CODE_CONTACTS
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        when (requestCode) {
            PermissionManager.REQUEST_CODE_RECORD_AUDIO -> {
                if (granted) {
                    speechManager.startListening()
                } else {
                    binding.tvResponse.text = getString(R.string.permission_denied_generic)
                }
            }
            PermissionManager.REQUEST_CODE_CAMERA,
            PermissionManager.REQUEST_CODE_CONTACTS -> {
                if (!granted) {
                    binding.tvResponse.text = getString(R.string.permission_denied_generic)
                }
                // If granted, the user can simply repeat their voice command;
                // we don't auto-retry to avoid surprising background actions.
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
        ttsManager.destroy()
        commandRouter.cancelPendingWork()
    }
}
