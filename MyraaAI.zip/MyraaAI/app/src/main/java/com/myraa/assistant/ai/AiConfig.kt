package com.myraa.assistant.ai

import com.myraa.assistant.BuildConfig

/**
 * Central place the AI layer reads its backend configuration from.
 * Values come from gradle.properties -> BuildConfig at compile time (see
 * app/build.gradle.kts), so no key or secret is ever hard-coded in a
 * committed .kt file. AI_AUTH_TOKEN should identify the app to YOUR OWN
 * backend — the backend is what actually holds the LLM provider's key.
 *
 * See README.md "Connecting the AI backend securely" for the full setup.
 */
object AiConfig {
    val baseUrl: String get() = BuildConfig.AI_BASE_URL
    val model: String get() = BuildConfig.AI_MODEL
    val authToken: String get() = BuildConfig.AI_AUTH_TOKEN

    val isConfigured: Boolean
        get() = baseUrl.isNotBlank() &&
            !baseUrl.contains("your-backend.example.com") &&
            authToken.isNotBlank() &&
            authToken != "REPLACE_WITH_YOUR_BACKEND_TOKEN"
}
