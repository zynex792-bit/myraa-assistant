package com.myraa.assistant.util

import java.util.Locale

/**
 * Cleans up raw speech-recognition output before it reaches the command
 * router: lower-cases it, trims filler words, and maps a handful of common
 * Hindi/Hinglish phrasings onto their English equivalents so a single set of
 * intent-matching rules in [com.myraa.assistant.command.CommandRouter] can
 * handle all three languages without duplicating every rule three times.
 *
 * This is NOT a translator — it only normalizes the small vocabulary Myraa's
 * command grammar actually cares about (open, search, play, message, call,
 * flashlight, alarm, etc). Anything else is passed through untouched so it
 * can fall through to the AI-chat path.
 */
object TextNormalizer {

    // Hindi/Hinglish phrase -> English keyword. Longest phrases first so
    // multi-word matches win before shorter ones can partially match.
    private val phraseMap = linkedMapOf(
        "khol do" to "open",
        "khol dijiye" to "open",
        "kholo" to "open",
        "khol" to "open",
        "band kar do" to "turn off",
        "band karo" to "turn off",
        "chalu kar do" to "turn on",
        "chalu karo" to "turn on",
        "on kar do" to "turn on",
        "off kar do" to "turn off",
        "dhundo" to "search",
        "khoj" to "search",
        "bajao" to "play",
        "sandesh bhejo" to "message",
        "message bhejo" to "message",
        "bhejo" to "send",
        "phone karo" to "call",
        "call karo" to "call",
        "alarm laga do" to "set an alarm",
        "alarm set karo" to "set an alarm",
        "torch" to "flashlight",
        "battery ki roshni" to "flashlight"
    )

    fun normalize(raw: String): String {
        var text = raw.trim().lowercase(Locale.getDefault())
        for ((phrase, replacement) in phraseMap) {
            if (text.contains(phrase)) {
                text = text.replace(phrase, replacement)
            }
        }
        return text.replace(Regex("\\s+"), " ").trim()
    }
}
