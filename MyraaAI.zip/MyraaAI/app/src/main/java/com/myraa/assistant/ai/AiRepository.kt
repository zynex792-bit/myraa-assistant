package com.myraa.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Keeps the AI layer fully separate from device-action logic, per the spec:
 * CommandRouter only ever calls this for the "normal question -> conversational
 * answer" path, never for app-control commands.
 */
class AiRepository(private val apiService: AiApiService = AiApiService()) {

    suspend fun ask(question: String): Result<String> = withContext(Dispatchers.IO) {
        when (val result = apiService.sendMessage(question)) {
            is AiApiService.AiResult.Success -> Result.success(result.reply)
            is AiApiService.AiResult.Failure -> Result.failure(Exception(result.reason))
        }
    }
}
