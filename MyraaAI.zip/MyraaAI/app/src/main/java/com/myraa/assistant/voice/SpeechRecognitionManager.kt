package com.myraa.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Wraps Android's on-device/on-server [SpeechRecognizer] with a small,
 * predictable callback surface. Deliberately does NOT auto-restart listening
 * on its own — MainActivity decides when to listen again — which is what
 * keeps Myraa from creating the "repeatedly triggers the microphone /
 * annoying popups" behavior called out in the requirements.
 */
class SpeechRecognitionManager(
    private val context: Context,
    private val listener: Callback
) {
    interface Callback {
        fun onReadyForSpeech() {}
        fun onPartialResult(text: String) {}
        fun onFinalResult(text: String)
        fun onError(message: String)
    }

    private var recognizer: SpeechRecognizer? = null
    private var isListening = false

    fun isCurrentlyListening(): Boolean = isListening

    /**
     * Language hint: supports English, Hindi, and lets the recognizer's own
     * language-detection help with Hinglish (mixed) speech, since Android's
     * SpeechRecognizer does not have a dedicated "Hinglish" locale. Using
     * en-IN as the primary locale gives the best real-world accuracy for
     * Hindi-accented/mixed English speech on most devices.
     */
    fun startListening(languageTag: String = "en-IN") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onError("Speech recognition isn't available on this device.")
            return
        }
        if (isListening) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    listener.onReadyForSpeech()
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isListening = false
                }

                override fun onError(error: Int) {
                    isListening = false
                    listener.onError(mapErrorCode(error))
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    val text = matches?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) {
                        listener.onFinalResult(text)
                    } else {
                        listener.onError("No speech detected.")
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )
                    matches?.firstOrNull()?.let { listener.onPartialResult(it) }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        try {
            recognizer?.startListening(intent)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to start listening", t)
            isListening = false
            listener.onError("Couldn't start listening. Please try again.")
        }
    }

    fun stopListening() {
        if (isListening) {
            recognizer?.stopListening()
            isListening = false
        }
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
        isListening = false
    }

    private fun mapErrorCode(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
        SpeechRecognizer.ERROR_CLIENT -> "Something went wrong. Please try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
        SpeechRecognizer.ERROR_NETWORK -> "Network error during recognition."
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out. Please try again."
        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer is busy, please wait a moment."
        SpeechRecognizer.ERROR_SERVER -> "Server error during recognition."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
        else -> "Unknown speech recognition error."
    }

    companion object {
        private const val TAG = "SpeechRecognition"
    }
}
