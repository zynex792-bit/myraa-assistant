package com.myraa.assistant.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.util.Calendar

/**
 * Parsed result of an alarm-time phrase.
 * [ambiguous] is true when we truly can't tell what the user meant (e.g. a
 * bare hour with no am/pm and no other context) — CommandRouter surfaces
 * this as a clarifying question instead of guessing, per the spec.
 */
sealed class AlarmTimeParseResult {
    data class Parsed(val hour: Int, val minute: Int, val message: String?) : AlarmTimeParseResult()
    data class Ambiguous(val clarifyingQuestion: String) : AlarmTimeParseResult()
    object NotFound : AlarmTimeParseResult()
}

object AlarmAction {

    private val timeRegex = Regex(
        """(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?""",
        RegexOption.IGNORE_CASE
    )

    /**
     * Attempts to pull an hour/minute out of natural phrases like
     * "7 AM", "6:30 tomorrow morning", "set alarm for 9".
     */
    fun parseTime(text: String): AlarmTimeParseResult {
        val match = timeRegex.find(text) ?: return AlarmTimeParseResult.NotFound

        var hour = match.groupValues[1].toIntOrNull() ?: return AlarmTimeParseResult.NotFound
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val meridiem = match.groupValues[3].lowercase().replace(".", "")

        val hasMorningWord = Regex("morning|subah").containsMatchIn(text)
        val hasEveningWord = Regex("evening|shaam|raat|night").containsMatchIn(text)

        if (hour > 23 || minute > 59) return AlarmTimeParseResult.NotFound

        when {
            meridiem == "pm" -> {
                if (hour in 1..11) hour += 12
            }
            meridiem == "am" -> {
                if (hour == 12) hour = 0
            }
            hasEveningWord -> {
                if (hour in 1..11) hour += 12
            }
            hasMorningWord -> {
                if (hour == 12) hour = 0
                // else treat as-is (already 0-11 range for morning)
            }
            hour in 1..11 -> {
                // No am/pm, no context word: genuinely ambiguous per spec.
                return AlarmTimeParseResult.Ambiguous(
                    "Did you mean $hour AM or $hour PM?"
                )
            }
            // hour == 0 or hour in 13..23 is already unambiguous 24h time
        }

        return AlarmTimeParseResult.Parsed(hour, minute, message = null)
    }

    /**
     * Hands off to the system Clock app via AlarmClock.ACTION_SET_ALARM.
     * This does NOT silently create the alarm — the Clock app itself may
     * ask the user to confirm, which is expected and correct behavior.
     * Returns true only if an app was actually found to handle the intent.
     */
    fun setAlarm(context: Context, hour: Int, minute: Int, label: String = "Myraa alarm"): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }

    fun formatTime12h(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
        }
        val h = if (hour % 12 == 0) 12 else hour % 12
        val amPm = if (hour < 12) "AM" else "PM"
        return String.format("%d:%02d %s", h, minute, amPm)
    }
}
