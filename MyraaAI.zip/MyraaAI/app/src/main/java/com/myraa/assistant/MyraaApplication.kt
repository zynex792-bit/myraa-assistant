package com.myraa.assistant

import android.app.Application

/**
 * Application entry point. Kept intentionally minimal — no global state that
 * would make the app harder to reason about. Add DI setup here later if the
 * project grows (Hilt/Koin), per the modular architecture goal.
 */
class MyraaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
