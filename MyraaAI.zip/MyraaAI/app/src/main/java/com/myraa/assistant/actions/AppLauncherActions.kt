package com.myraa.assistant.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

/**
 * All "open X app" / deep-link actions. Every function returns a Boolean so
 * CommandRouter can honestly report success/failure — per the "never claim
 * an action was completed unless it actually happened" requirement, we only
 * say we opened something if startActivity() didn't throw.
 */
object AppLauncherActions {

    private fun safeStart(context: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    fun openYouTube(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
        return safeStart(context, intent)
    }

    /** Opens YouTube search results for [query] using YouTube's search deep link. */
    fun searchYouTube(context: Context, query: String): Boolean {
        val uri = Uri.parse(
            "https://www.youtube.com/results?search_query=" + Uri.encode(query)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.youtube")
        }
        // Fall back to a normal browser view if the YouTube app isn't installed.
        return safeStart(context, intent) || safeStart(context, Intent(Intent.ACTION_VIEW, uri))
    }

    /** "Play X on YouTube" — YouTube doesn't guarantee auto-play from a deep
     * link for arbitrary search text, so this opens the search results,
     * which the user can tap the first result of. This is an honest
     * representation of what the intent actually does. */
    fun playOnYouTube(context: Context, query: String): Boolean = searchYouTube(context, query)

    fun openInstagram(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com"))
        return safeStart(context, intent)
    }

    fun openWhatsApp(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
        return if (intent != null) safeStart(context, intent) else false
    }

    fun openChrome(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage("com.android.chrome")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        return safeStart(context, intent)
    }

    fun openCamera(context: Context): Boolean {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        return safeStart(context, intent)
    }

    fun openGallery(context: Context): Boolean {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            type = "image/*"
        }
        return safeStart(context, intent)
    }

    fun openCalculator(context: Context): Boolean {
        // No universal public intent action exists for "open calculator" —
        // this tries the most common calculator package names, which is the
        // closest legitimate solution without relying on hidden APIs.
        val knownPackages = listOf(
            "com.google.android.calculator",
            "com.android.calculator2",
            "com.sec.android.app.popupcalculator",
            "com.miui.calculator",
            "com.oneplus.calculator"
        )
        for (pkg in knownPackages) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null && safeStart(context, intent)) return true
        }
        return false
    }

    fun openMaps(context: Context, query: String? = null): Boolean {
        val uri = if (!query.isNullOrBlank()) {
            Uri.parse("geo:0,0?q=" + Uri.encode(query))
        } else {
            Uri.parse("geo:0,0?q=")
        }
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.apps.maps")
        }
        return safeStart(context, intent) || safeStart(
            context,
            Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com"))
        )
    }

    fun openSettings(context: Context): Boolean {
        return safeStart(context, Intent(Settings.ACTION_SETTINGS))
    }

    /** Generic fallback: tries to launch any installed app whose visible
     * label matches [appName] (case-insensitive, partial match). */
    fun openInstalledAppByName(context: Context, appName: String): Boolean {
        val pm = context.packageManager
        val launchables = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val normalized = appName.trim().lowercase()
        val match = launchables.firstOrNull { info ->
            info.loadLabel(pm).toString().lowercase().contains(normalized)
        } ?: return false

        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        return safeStart(context, intent)
    }

    fun openDialer(context: Context, phoneNumber: String? = null): Boolean {
        val uri = if (!phoneNumber.isNullOrBlank()) Uri.parse("tel:$phoneNumber") else Uri.parse("tel:")
        return safeStart(context, Intent(Intent.ACTION_DIAL, uri))
    }

    fun openContacts(context: Context): Boolean {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = android.provider.ContactsContract.Contacts.CONTENT_URI
        }
        return safeStart(context, intent)
    }
}
