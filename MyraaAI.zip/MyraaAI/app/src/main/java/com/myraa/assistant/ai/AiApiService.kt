package com.myraa.assistant.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Talks to YOUR backend at [AiConfig.baseUrl] — never directly to an LLM
 * provider, and never with a provider API key embedded in the app. Your
 * backend is expected to accept a small JSON payload and return a JSON
 * object of the shape { "reply": "..." }. Adapt the request/response
 * shape here to match whatever contract your backend actually exposes.
 */
class AiApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    sealed class AiResult {
        data class Success(val reply: String) : AiResult()
        data class Failure(val reason: String) : AiResult()
    }

    fun sendMessage(userMessage: String): AiResult {
        if (!AiConfig.isConfigured) {
            return AiResult.Failure(
                "AI backend isn't configured yet. Set MYRAA_AI_BASE_URL and " +
                    "MYRAA_AI_AUTH_TOKEN in gradle.properties."
            )
        }

        val payload = JSONObject().apply {
            put("model", AiConfig.model)
            put("message", userMessage)
        }

        val request = Request.Builder()
            .url(AiConfig.baseUrl)
            .addHeader("Authorization", "Bearer ${AiConfig.authToken}")
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return AiResult.Failure("Backend returned status ${response.code}.")
                }
                val json = JSONObject(bodyString)
                val reply = json.optString("reply").ifBlank { null }
                    ?: return AiResult.Failure("Backend response was missing a reply.")
                AiResult.Success(reply)
            }
        } catch (e: IOException) {
            AiResult.Failure("Couldn't reach the AI backend. Check your internet connection.")
        } catch (e: Exception) {
            AiResult.Failure("Unexpected error talking to the AI backend.")
        }
    }
}
