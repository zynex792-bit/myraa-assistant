package com.myraa.assistant.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.util.Log

data class ContactMatch(val name: String, val phoneNumber: String)

/**
 * WhatsApp messaging support. Per the spec, Myraa must NEVER guess a contact
 * or message: this class only ever *looks up* candidates and *prepares* the
 * WhatsApp intent — CommandRouter is responsible for making the user
 * explicitly confirm both the recipient and message text before this send
 * step is actually invoked.
 */
object WhatsAppAction {

    private const val TAG = "WhatsAppAction"

    /** Looks up contacts whose display name contains [name] (case-insensitive). */
    fun findContacts(context: Context, name: String): List<ContactMatch> {
        val results = mutableListOf<ContactMatch>()
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$name%")

        try {
            resolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val contactName = cursor.getString(nameIdx) ?: continue
                    val number = cursor.getString(numberIdx) ?: continue
                    results.add(ContactMatch(contactName, number))
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Contacts permission not granted", e)
        }
        return results.distinctBy { it.phoneNumber }
    }

    /**
     * Opens a WhatsApp chat with [phoneNumber] pre-filled with [message].
     * This still lands the user in WhatsApp's own send screen — WhatsApp
     * does not expose a public API to auto-send without user interaction,
     * so the final tap-to-send in WhatsApp is the user's explicit final
     * confirmation, which is the correct and only legitimate behavior here.
     */
    fun openChatWithPrefilledMessage(context: Context, phoneNumber: String, message: String): Boolean {
        val cleanNumber = phoneNumber.filter { it.isDigit() || it == '+' }
        val uri = Uri.parse(
            "https://wa.me/$cleanNumber?text=" + Uri.encode(message)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            false
        }
    }
}
